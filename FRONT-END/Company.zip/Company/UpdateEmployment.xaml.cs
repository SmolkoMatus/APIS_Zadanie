﻿using Company.Magic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Company
{
    /// <summary>
    /// Interaction logic for UpdateEmployment.xaml
    /// </summary>
    public partial class UpdateEmployment : Window
    {
        private ControllerEmployment controllerEmployment;

        public UpdateEmployment(ControllerEmployment controllerEmployment)
        {
            InitializeComponent();
            this.controllerEmployment = controllerEmployment;
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AddressEmploymentTextBox.Text = this.controllerEmployment.Employments.AddressEmployment;
            PhoneNumberEmploymentTextBox.Text = this.controllerEmployment.Employments.PhoneNumberEmployment;
            EmailEmploymentTextBox.Text = this.controllerEmployment.Employments.EmailEmployment;
        }

        private void OkBtn_Click(object sender, RoutedEventArgs e)
        {
            bool uptd = controllerEmployment.ChangeEmployment(AddressEmploymentTextBox.Text, PhoneNumberEmploymentTextBox.Text, EmailEmploymentTextBox.Text);
            if(uptd == true)
            {
                this.Close();
            }
            else
            {
                System.Windows.MessageBox.Show("Wrong input!");
            }
        }
    }
}
