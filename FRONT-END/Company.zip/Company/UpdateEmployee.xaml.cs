﻿using Company.Magic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Company
{
    /// <summary>
    /// Interaction logic for UpdateEmployee.xaml
    /// </summary>
    public partial class UpdateEmployee : Window
    {
        private ControllerEmployee controllerEmployee;

        public UpdateEmployee(ControllerEmployee controllerEmployee)
        {
            InitializeComponent();

            this.controllerEmployee = controllerEmployee;
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            NameEmployeeTextBox.Text = this.controllerEmployee.Employee.Name;
            LastNameEmployeeTextBox.Text = this.controllerEmployee.Employee.LastName;
            HireDateEmployeeTextBox.Text = this.controllerEmployee.Employee.HireDate;
            AddressEmployeeTextBox.Text = this.controllerEmployee.Employee.Address;
            CurrentSalaryEmployeeTextBox.Text = this.controllerEmployee.Employee.CurrentSalary.ToString();
        }

        private void OkBtn_Click(object sender, RoutedEventArgs e)
        {
            bool uptd = controllerEmployee.ChangeEmployee(NameEmployeeTextBox.Text, LastNameEmployeeTextBox.Text, HireDateEmployeeTextBox.Text, AddressEmployeeTextBox.Text, CurrentSalaryEmployeeTextBox.Text);

            if (uptd == true)
            {
                this.Close();
            }
            else
            {
                System.Windows.MessageBox.Show("Wrong input!");
            }
        }
    }
}
