﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Company.Magic;


namespace Company
{

    /// <summary>
    /// Interaction logic for AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        private ControllerEmployee controllerEmployee;
        private ControllerEmployment controllerEmployment;
        private ControllerWorkPosition controllerWorkPosition;

        public AddWindow(ControllerEmployee controllerEmployee, ControllerEmployment controllerEmployment, ControllerWorkPosition controllerWorkPosition)
        {
            InitializeComponent();
            this.controllerEmployee = controllerEmployee;
            this.controllerEmployment = controllerEmployment;
            this.controllerWorkPosition = controllerWorkPosition;
            HideAll();
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            bool close = false;
            if (EmployeeRButton.IsChecked == true)
            {
                controllerEmployee.Employee = new Employee();
                close = TakeEmployee();
            }
            if (EmploymentRButton.IsChecked == true)
            {
                controllerEmployment.Employments = new Employments();
               close = TakeEmployment();
            }
            if (WorkPositionRButton.IsChecked == true)
            {
                controllerWorkPosition.WorkPosition = new WorkPosition();
                close = TakeWorkPosition();
            }
            if(close == true)
            {
                System.Windows.MessageBox.Show("Your input was added!");
                this.Close();
            }
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            ClearAll();
            Close();
        }
        private void EmployeeRButton_Checked(object sender, RoutedEventArgs e)
        {
            ShowEmployee();
            HideEmployment();
            ClearEmployment();
            HideWorkPosition();
            ClearWorkPosition();
        }
        private void HideAll()
        {
            HideEmployee();
            HideEmployment();
            HideWorkPosition();
        }
        private void HideWorkPosition()
        {
            WorkPositionActivityCostTextBox.Visibility = Visibility.Collapsed;
            WorkPositionActivityCostLabel.Visibility = Visibility.Collapsed;
            WorkPositionBonusSalaryTextBox.Visibility = Visibility.Collapsed;
            WorkPositionBonusSalaryLabel.Visibility = Visibility.Collapsed;
            WorkPositionSalaryMinTextBox.Visibility = Visibility.Collapsed;
            WorkPositionSalaryMinLabel.Visibility = Visibility.Collapsed;
            WorkPositionNamePositionTextBox.Visibility = Visibility.Collapsed;  
            WorkPositionNamePositionLabel.Visibility = Visibility.Collapsed;
            WorkPositionSalaryMaxTextBox.Visibility = Visibility.Collapsed;
            WorkPositionSalaryMaxLabel.Visibility = Visibility.Collapsed;
            WorkPositionPenalizationSalaryTextBox.Visibility = Visibility.Collapsed;
            WorkPositionPenalizationSalaryLabel.Visibility = Visibility.Collapsed;
        }
        private void HideEmployee()
        {
            EmployeeNameTextBox.Visibility = Visibility.Collapsed;
            EmployeeNameLabel.Visibility = Visibility.Collapsed;
            EmployeeLastNameTextBox.Visibility = Visibility.Collapsed;
            EmployeeLastNameLabel.Visibility = Visibility.Collapsed;
            EmployeeHireDateTextBox.Visibility = Visibility.Collapsed;
            EmployeeHireDateLabel.Visibility = Visibility.Collapsed;
            EmployeeAddressTextBox.Visibility = Visibility.Collapsed;
            EmployeeAddressLabel.Visibility = Visibility.Collapsed;
            EmployeeSalaryTextBox.Visibility = Visibility.Collapsed;
            EmployeeSalaryLabel.Visibility = Visibility.Collapsed;
        }
        private void HideEmployment()
        {
            EmploymentAddressTextBox.Visibility = Visibility.Collapsed;
            EmploymentAddressLabel.Visibility = Visibility.Collapsed;
            EmploymentEmailAddressTextBox.Visibility = Visibility.Collapsed;
            EmploymentEmailLabel.Visibility = Visibility.Collapsed;
            EmploymentPhoneNumberTextBox.Visibility = Visibility.Collapsed;
            EmploymentPhoneNumberLabel.Visibility = Visibility.Collapsed;
        }
        private void ShowWorkPosition()
        {
            WorkPositionActivityCostTextBox.Visibility = Visibility.Visible;
            WorkPositionActivityCostLabel.Visibility = Visibility.Visible;
            WorkPositionBonusSalaryTextBox.Visibility = Visibility.Visible;
            WorkPositionBonusSalaryLabel.Visibility = Visibility.Visible;   
            WorkPositionSalaryMinTextBox.Visibility = Visibility.Visible;
            WorkPositionSalaryMinLabel.Visibility = Visibility.Visible;
            WorkPositionNamePositionTextBox.Visibility = Visibility.Visible;
            WorkPositionNamePositionLabel.Visibility = Visibility.Visible;
            WorkPositionSalaryMaxTextBox.Visibility = Visibility.Visible;
            WorkPositionSalaryMaxLabel.Visibility = Visibility.Visible;
            WorkPositionPenalizationSalaryTextBox.Visibility = Visibility.Visible;
            WorkPositionPenalizationSalaryLabel.Visibility = Visibility.Visible;
        }
        private void ShowEmployment()
        {
            EmploymentAddressTextBox.Visibility = Visibility.Visible;
            EmploymentAddressLabel.Visibility = Visibility.Visible;
            EmploymentEmailAddressTextBox.Visibility = Visibility.Visible;
            EmploymentEmailLabel.Visibility = Visibility.Visible;
            EmploymentPhoneNumberTextBox.Visibility = Visibility.Visible;
            EmploymentPhoneNumberLabel.Visibility = Visibility.Visible;
        }
        private void ShowEmployee()
        {
            EmployeeNameTextBox.Visibility = Visibility.Visible;
            EmployeeNameLabel.Visibility = Visibility.Visible;
            EmployeeLastNameTextBox.Visibility = Visibility.Visible;
            EmployeeLastNameLabel.Visibility = Visibility.Visible;
            EmployeeHireDateTextBox.Visibility = Visibility.Visible;
            EmployeeHireDateLabel.Visibility = Visibility.Visible;  
            EmployeeAddressTextBox.Visibility = Visibility.Visible;
            EmployeeAddressLabel.Visibility = Visibility.Visible;   
            EmployeeSalaryTextBox.Visibility = Visibility.Visible;
            EmployeeSalaryLabel.Visibility = Visibility.Visible;
        }
        private void EmploymentRButton_Checked(object sender, RoutedEventArgs e)
        {
            ShowEmployment();
            HideEmployee();
            ClearEmployee();
            HideWorkPosition();
            ClearWorkPosition();
        }
        private void WorkPositionRButton_Checked(object sender, RoutedEventArgs e)
        {
            ShowWorkPosition();
            HideEmployee();
            ClearEmployee();
            HideEmployment();
            ClearEmployment();
        }
        private void ClearAll()
        {
            ClearEmployee();
            ClearEmployment();
            ClearWorkPosition();
        }
        private void ClearWorkPosition()
        {
            WorkPositionActivityCostTextBox.Text = string.Empty;
            WorkPositionBonusSalaryTextBox.Text = string.Empty;
            WorkPositionSalaryMinTextBox.Text = string.Empty;
            WorkPositionNamePositionTextBox.Text = string.Empty;
            WorkPositionSalaryMaxTextBox.Text = string.Empty;
            WorkPositionPenalizationSalaryTextBox.Text= string.Empty;
        }
        private void ClearEmployee()
        {
            EmployeeNameTextBox.Text = string.Empty;
            EmployeeLastNameTextBox.Text = string.Empty;
            EmployeeHireDateTextBox.Text = string.Empty;
            EmployeeAddressTextBox.Text = string.Empty;
            EmployeeSalaryTextBox.Text = string.Empty;
        }
        private void ClearEmployment()
        {
            EmploymentAddressTextBox.Text= string.Empty;
            EmploymentEmailAddressTextBox.Text= string.Empty;
            EmploymentPhoneNumberTextBox.Text= string.Empty;
        }
        private bool TakeEmployee()
        {
            bool add = false;
            add = controllerEmployee.ChangeEmployee(EmployeeNameTextBox.Text, EmployeeLastNameTextBox.Text, EmployeeHireDateTextBox.Text, EmployeeAddressTextBox.Text, EmployeeSalaryTextBox.Text);
            if (add==false)
            {
                System.Windows.MessageBox.Show("Wrong input!");
            }
            return add;
        }
        private bool TakeEmployment()
        {
            bool add = false;
            add = controllerEmployment.ChangeEmployment(EmploymentAddressTextBox.Text, EmploymentPhoneNumberTextBox.Text, EmploymentEmailAddressTextBox.Text);
            if (add == false)
            {
                System.Windows.MessageBox.Show("Wrong input!");
            }
            return add;
        }
        private bool TakeWorkPosition()
        {
            bool add = false;
            add = controllerWorkPosition.ChangeWorkPosition(WorkPositionNamePositionTextBox.Text, WorkPositionSalaryMinTextBox.Text,WorkPositionSalaryMaxTextBox.Text, WorkPositionActivityCostTextBox.Text, WorkPositionBonusSalaryTextBox.Text, WorkPositionPenalizationSalaryTextBox.Text);
            if (add == false)
            {
                System.Windows.MessageBox.Show("Wrong input!");
            }
            return add;
        }
    }
}

