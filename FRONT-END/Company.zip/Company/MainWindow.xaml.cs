﻿using Company.Magic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;


namespace Company
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ControllerEmployee controllerEmployee = new ControllerEmployee();
        private ControllerEmployment controllerEmployment = new ControllerEmployment();
        private ControllerWorkPosition controllerWorkPosition = new ControllerWorkPosition();
        string pathEmployment = @"json\\Employment.json";
        string pathEmployee = @"json\\Employee.json";
        string pathWorkPosition = @"json\\WorkPosition.json";


        public MainWindow()
        {
            InitializeComponent();
            LoadJSON();
            ShowJson();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadJSON();
            ShowJson();
            UpdatePlot();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            
            AddWindow addWindow = new AddWindow(controllerEmployee, controllerEmployment, controllerWorkPosition);
            addWindow.Show();
        }

        private void LoadJSON()
        {
            controllerEmployee.LoadJSONEmployee(pathEmployee);
            controllerEmployment.LoadJSONEmployment(pathEmployment);
            controllerWorkPosition.LoadJSONWorkPosition(pathWorkPosition);
        }
        private void ShowJson()
        {
            EmployeeDataGrid.ItemsSource = controllerEmployee.GetEmployee;
            EmploymentDataGrid.ItemsSource = controllerEmployment.GetEmployment;
            WorkPositionDataGrid.ItemsSource = controllerWorkPosition.GetWorkPositions;
        }

        private void EmployeeDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //update
            controllerEmployee.Employee = (Employee)EmployeeDataGrid.SelectedItem;
            UpdateEmployee updateEmployee = new UpdateEmployee(controllerEmployee);
            updateEmployee.Show();
        }

        private void EmploymentDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //update
            controllerEmployment.Employments = (Employments)EmploymentDataGrid.SelectedItem;
            UpdateEmployment updateEmployment = new UpdateEmployment(controllerEmployment);
            updateEmployment.Show();
        }

        private void WorkPositionDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //update
            controllerWorkPosition.WorkPosition = (WorkPosition)WorkPositionDataGrid.SelectedItem;
            UpdateWorkPosition updateWorkPosition = new UpdateWorkPosition(controllerWorkPosition);
            updateWorkPosition.Show();
        }

        private void EmployeeDataGrid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            controllerEmployee.RemoveEmployee((Employee)EmployeeDataGrid.SelectedItem);
        }

        private void EmploymentDataGrid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            controllerEmployment.RemoveEmployment((Employments)EmploymentDataGrid.SelectedItem);
        }

        private void WorkPositionDataGrid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            controllerWorkPosition.RemoveWorkPosition((WorkPosition)WorkPositionDataGrid.SelectedItem); 
        }



        private PlotModel plotModel = new PlotModel();
        private BarSeries barSeries = new BarSeries();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.plotModel.Background = OxyColor.FromRgb(255, 255, 255);
            this.plotModel.Series.Add(this.barSeries);
            this.UpdatePlot();
            this.Plot.Model = this.plotModel;
        }
        private void UpdatePlot()
        {
            Dictionary<string, BarItem> barItems = new Dictionary<string, BarItem>();
            controllerEmployee.GetEmployee.ForEach(delegate (Employee employee)
            {
                barItems.Add(employee.Name, new BarItem
                {
                    Value = employee.CurrentSalary,
                    Color = OxyColor.FromRgb(0, 0, 1)
                });
            });

            barItems = barItems.Reverse().ToDictionary(x => x.Key, y => y.Value);
            this.barSeries.ItemsSource = barItems.Values;
            this.plotModel.Axes.Clear();
            this.plotModel.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, FontSize = 20, Title = "Salary" });
            this.plotModel.Axes.Add(new CategoryColorAxis
            {
                Position = AxisPosition.Left,
                FontSize = 20,
                ItemsSource = barItems.Keys
            });
            this.plotModel.InvalidatePlot(true);
        }
    }
}
