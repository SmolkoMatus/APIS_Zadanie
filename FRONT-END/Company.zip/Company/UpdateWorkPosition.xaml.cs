﻿using Company.Magic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Company
{
    /// <summary>
    /// Interaction logic for UpdateWorkPosition.xaml
    /// </summary>
    public partial class UpdateWorkPosition : Window
    {
        private ControllerWorkPosition controllerWorkPosition;

        public UpdateWorkPosition(ControllerWorkPosition controllerWorkPosition)
        {
            InitializeComponent();
            this.controllerWorkPosition = controllerWorkPosition;
        }
        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            NameWorkPositionTextBox.Text = controllerWorkPosition.WorkPosition.WorkPositionname;
            SalaryMinWorkPositionTextBox.Text = controllerWorkPosition.WorkPosition.SalaryMin.ToString();
            SalaryMaxWorkPositionTextBox.Text = controllerWorkPosition.WorkPosition.SalaryMax.ToString();
            ActivityCostWorkPositionTextBox.Text = controllerWorkPosition.WorkPosition.ActivityCost.ToString();
            BonusSalaryWorkPositionTextBox.Text = controllerWorkPosition.WorkPosition.BonusSalary.ToString();
            PenalizationSalary.Text = controllerWorkPosition.WorkPosition.PenalizationSalary.ToString();
        }

        private void OkBtn_Click(object sender, RoutedEventArgs e)
        {
            bool uptd = controllerWorkPosition.ChangeWorkPosition(NameWorkPositionTextBox.Text, SalaryMinWorkPositionTextBox.Text, SalaryMaxWorkPositionTextBox.Text, ActivityCostWorkPositionTextBox.Text, BonusSalaryWorkPositionTextBox.Text, PenalizationSalary.Text);
            if (uptd)
            {
                this.Close();
            }
            else
            {
                System.Windows.MessageBox.Show("Wrong input!");
            }
        }
    }
}
