﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace Company.Magic
{
    public  class Employee
    {
        private string name;
        private string lastName;
        private string hireDate;
        private string address;
        private int currentSalary;

        public string Name { get => name; set => name = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string HireDate { get => hireDate; set => hireDate = value; }
        public string Address { get => address; set => address = value; }
        public int CurrentSalary { get => currentSalary; set => currentSalary = value; }

    }
}
