﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company.Magic
{
    public class WorkPosition
    {

        private string workPositionname;
        private int salaryMin;
        private int salaryMax;
        private int activityCost;
        private int bonusSalary;
        private int penalizationSalary;

        public string WorkPositionname { get => workPositionname; set => workPositionname = value; }
        public int SalaryMin { get => salaryMin; set => salaryMin = value; }
        public int SalaryMax { get => salaryMax; set => salaryMax = value; }
        public int ActivityCost { get => activityCost; set => activityCost = value; }
        public int BonusSalary { get => bonusSalary; set => bonusSalary = value; }
        public int PenalizationSalary { get => penalizationSalary; set => penalizationSalary = value; }
    }
}
