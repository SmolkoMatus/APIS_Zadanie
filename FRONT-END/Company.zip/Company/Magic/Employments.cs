﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company.Magic
{
    public class Employments
    {
        private string addressEmployment;
        private string phoneNumberEmployment;
        private string emailEmployment;

        public string AddressEmployment { get => addressEmployment; set => addressEmployment = value; }
        public string PhoneNumberEmployment { get => phoneNumberEmployment; set => phoneNumberEmployment = value; }
        public string EmailEmployment { get => emailEmployment; set => emailEmployment = value; }
    }
}
