﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company.Magic
{
    public class ControllerWorkPosition
    {
        private List<WorkPosition> workPositions = new List<WorkPosition>();
        public List<WorkPosition> GetWorkPositions { get => workPositions; set => workPositions = value; }
        public WorkPosition WorkPosition { get; set; }
        private string pathWorkPosition;
        public void LoadJSONWorkPosition(string pathWorkPosition)
        {   this.pathWorkPosition = pathWorkPosition;
            using (StreamReader r = new StreamReader(pathWorkPosition))
            {
                string json = r.ReadToEnd();
                workPositions = JsonConvert.DeserializeObject<List<WorkPosition>>(json);
            }
        }
        private int result = 0;
        public bool ChangeWorkPosition(string name, string salaryMin, string salaryMax, string activityCost, string bonusSalary, string penalizationSalary)
        {
            if (name == string.Empty || salaryMin == string.Empty || salaryMax == string.Empty || activityCost == string.Empty || bonusSalary == string.Empty || penalizationSalary == string.Empty)
            {
                return false;
            }
            if (!int.TryParse(salaryMin, out result) || !int.TryParse(salaryMax, out result) || !int.TryParse(activityCost, out result) || !int.TryParse(bonusSalary, out result) || !int.TryParse(penalizationSalary, out result))
            {
                return false;
            }
            WorkPosition.WorkPositionname = name;
            WorkPosition.SalaryMin = int.Parse(salaryMin);
            WorkPosition.SalaryMax = int.Parse(salaryMax);
            WorkPosition.ActivityCost = int.Parse(activityCost);
            WorkPosition.BonusSalary = int.Parse(bonusSalary);
            WorkPosition.PenalizationSalary = int.Parse(penalizationSalary);

            if (!GetWorkPositions.Contains(WorkPosition))
            {
                GetWorkPositions.Add(WorkPosition);
            }
            else
            {
                //
            }
            AddWorkPosition(pathWorkPosition);
            return true;
        }

        public void AddWorkPosition(string pathworkPosition)
        {
            using (StreamWriter r = new StreamWriter(pathworkPosition))
            {
                string json = JsonConvert.SerializeObject(workPositions);
                r.Write(json);
            }
        }
        public void RemoveWorkPosition(WorkPosition workPositionDelete)
        {
            workPositions.Remove(workPositionDelete);
            AddWorkPosition(pathWorkPosition);
        }
    }
}