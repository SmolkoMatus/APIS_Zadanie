﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Company.Magic
{
    public class ControllerEmployment
    {
        private List<Employments> employment;
        private string pathEmployment;
        public List<Employments> GetEmployment { get => employment; set => employment = value; }
        public Employments Employments { get;set; }
        public void LoadJSONEmployment(string pathEmployment)
        {   this.pathEmployment = pathEmployment;
            using (StreamReader r = new StreamReader(pathEmployment))
            {
                string json = r.ReadToEnd();
                employment = JsonConvert.DeserializeObject<List<Employments>>(json);
            }
        }
        public bool ChangeEmployment(string address, string phone, string email)
        {
            if(address == string.Empty || phone == string.Empty || email == string.Empty)
            {
                return false;
            }

            Employments.AddressEmployment = address;
            Employments.PhoneNumberEmployment = phone;
            Employments.EmailEmployment = email;
            if (!GetEmployment.Contains(Employments))
            {
                employment.Add(Employments);   
            }
            else
            {
                //
            }
            AddEmployment(pathEmployment);
            return true;
        }
        public void AddEmployment(string pathEmployment)
        {
            using (StreamWriter r = new StreamWriter(pathEmployment))
            {
                string json = JsonConvert.SerializeObject(employment);
                r.Write(json);
            }
        }
        public void RemoveEmployment(Employments employmentDelete)
        {
            employment.Remove(employmentDelete);
            AddEmployment(pathEmployment);
        }
    }
}
