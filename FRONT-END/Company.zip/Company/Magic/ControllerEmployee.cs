﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company.Magic
{
    public class ControllerEmployee
    {
        private List<Employee> employee = new List<Employee>();
        public Employee Employee { get;set; }
        public List<Employee> GetEmployee { get => employee; set => employee = value; }
        private string pathEmployee;  
        public  void LoadJSONEmployee(string pathEmployee)
        {
            this.pathEmployee = pathEmployee;
            using (StreamReader r = new StreamReader(pathEmployee))
            {
                string json = r.ReadToEnd();
                employee = JsonConvert.DeserializeObject<List<Employee>>(json);
            }
        }
        private int result = 0;
        public bool ChangeEmployee(string name, string lastName, string hireDate, string address, string currentSalary)
        {
            if(name == string.Empty || lastName == string.Empty || hireDate == string.Empty || address == string.Empty || currentSalary == string.Empty)
            {
                return false;
            }
            if (!int.TryParse(currentSalary,out result))
            {
                return false;
            }
            Employee.Name = name;
            Employee.LastName = lastName;
            Employee.HireDate = hireDate;
            Employee.Address = address;
            Employee.CurrentSalary = int.Parse(currentSalary);
            if (!GetEmployee.Contains(Employee))
            {
                employee.Add(Employee);
            }
            else
            {
                //
            }
            AddEmployee(pathEmployee);
            return true;
        }
        public void AddEmployee(string pathEmployee)
        {
            using (StreamWriter r = new StreamWriter(pathEmployee))
            {
                string json = JsonConvert.SerializeObject(employee);
                r.Write(json);
            }
        }
        public void RemoveEmployee(Employee employeeDelete)
        {
            employee.Remove(employeeDelete);
            AddEmployee(pathEmployee);
        }
    }
}
